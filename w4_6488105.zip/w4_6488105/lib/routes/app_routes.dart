import 'package:flutter/material.dart';
import 'package:nadia/presentation/map_screen/map_screen.dart';

class AppRoutes {
  static const String mapScreen = '/map_screen';

  static Map<String, WidgetBuilder> routes = {
    mapScreen: (context) => MapScreen()
  };
}
