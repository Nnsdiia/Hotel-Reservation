import 'package:flutter/material.dart';
import 'package:nadia/core/app_export.dart';
import 'package:nadia/widgets/custom_elevated_button.dart';
import 'package:nadia/widgets/custom_icon_button.dart';
import 'package:nadia/widgets/custom_rating_bar.dart';

class MapScreen extends StatelessWidget {
  const MapScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBody: true,
        extendBodyBehindAppBar: true,
        body: Container(
          width: SizeUtils.width,
          height: SizeUtils.height,
          decoration: BoxDecoration(
            color: appTheme.gray200,
            image: DecorationImage(
              image: AssetImage(
                ImageConstant.imgMap,
              ),
              fit: BoxFit.cover,
            ),
          ),
          child: Container(
            width: double.maxFinite,
            padding: EdgeInsets.symmetric(
              horizontal: 9.h,
              vertical: 25.v,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(height: 4.v),
                _buildRowWithIconButtons(context),
                Spacer(),
                _buildColumnWithWidgets(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildRowWithIconButtons(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CustomIconButton(
            height: 39.v,
            width: 40.h,
            padding: EdgeInsets.all(10.h),
            child: CustomImageView(
              imagePath: ImageConstant.imgFrame2,
            ),
          ),
          CustomIconButton(
            height: 39.v,
            width: 40.h,
            padding: EdgeInsets.all(7.h),
            child: CustomImageView(
              imagePath: ImageConstant.imgFrame17,
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildColumnWithWidgets(BuildContext context) {
    return Container(
      width: 412.h,
      padding: EdgeInsets.symmetric(
        horizontal: 23.h,
        vertical: 12.v,
      ),
      decoration: AppDecoration.fillWhiteA.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder50,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 7.v),
          SizedBox(
            height: 90.v,
            width: 256.h,
            child: Stack(
              alignment: Alignment.topLeft,
              children: [
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: 256.h,
                        child: Text(
                          "1/3 Moo.6, Thanarat Moo-Si Pak Chong District, Nakhon Ratchasima 30130",
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: CustomTextStyles.titleSmallBlack900,
                        ),
                      ),
                      SizedBox(height: 7.v),
                      Row(
                        children: [
                          CustomRatingBar(
                            initialRating: 4,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 31.h),
                            child: Text(
                              "5.0 -1231 Reviews",
                              style: theme.textTheme.titleSmall,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    "Kirimaya Khao Yai",
                    style: theme.textTheme.headlineSmall,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 11.v),
          CustomElevatedButton(
            width: 121.h,
            text: "Direction",
            alignment: Alignment.centerRight,
          ),
        ],
      ),
    );
  }
}
