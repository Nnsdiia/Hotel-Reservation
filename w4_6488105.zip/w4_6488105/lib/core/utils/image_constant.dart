class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Map images
  static String imgMap = '$imagePath/img_map.png';

  static String imgFrame2 = '$imagePath/img_frame_2.png';

  static String imgFrame17 = '$imagePath/img_frame_17.png';

  static String imgClose = '$imagePath/img_close.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
